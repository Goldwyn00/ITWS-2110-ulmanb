This lab was a bit of a challenge as it was just quite a bit of tedious work getting all the different bits togethor since there was a lot of manual typing for each part.
Some key assumptions I made was that despite it saying it should be index.html, we are working in php so I assume that it meant to say index.php. Additionally, another assumption I made
was for question 8, it is somewhat ambigious whether the goal is to list out every student, and say whether or not they had a grade of 90 or higher, or if I should list out the students
who had a grade of 90 or higher. I made the latter assumption. Additionally, I assumed that CSS was not an important component of this assignment, so the page is just plain HTML, since I
assume the goal is to demonstrate profeciency with using MySQL through phpMyAdmin. Finally, one more comment is that all the data in the tables is completely fabricated,
so no real students were used, the class names, CRNS, rin numbers, rcsIDs, and so on are all just random things that I came up with.

Outside sources used:

https://www.w3schools.com/sql/sql_create_table.asp
https://www.w3schools.com/sql/sql_alter.asp

